package ru.pluginteam.mctrainer;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.plugin.java.JavaPlugin;
import ru.pluginteam.mctrainer.command.AdminCommand;
import ru.pluginteam.mctrainer.command.DuelTrainerCommand;
import ru.pluginteam.mctrainer.command.LeaveCommand;
import ru.pluginteam.mctrainer.command.PracticeCommand;
import ru.pluginteam.mctrainer.listener.TrainingListener;
import ru.pluginteam.mctrainer.model.TrainerType;
import ru.pluginteam.mctrainer.session.SessionManager;
import ru.pluginteam.mctrainer.storage.PlayerDataStore;

public class MCTrainerPlugin extends JavaPlugin {

    private PlayerDataStore dataStore;
    private SessionManager sessionManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.dataStore = new PlayerDataStore(this);
        this.sessionManager = new SessionManager(this);

        getCommand("practice").setExecutor(new PracticeCommand(this));
        getCommand("leave").setExecutor(new LeaveCommand(this));
        getCommand("tracking").setExecutor(new DuelTrainerCommand(this, TrainerType.TRACKING));
        getCommand("flick").setExecutor(new DuelTrainerCommand(this, TrainerType.FLICK));
        getCommand("mctrainer").setExecutor(new AdminCommand(this));

        Bukkit.getPluginManager().registerEvents(new TrainingListener(this), this);

        getLogger().info("MCtrainerPlus 2.2.1 успешно запущен!");
    }

    @Override
    public void onDisable() {
        if (sessionManager != null) {
            sessionManager.shutdownAll();
        }
        if (dataStore != null) {
            dataStore.save();
        }
    }

    public Material getFlickBlockMaterial() {
        String name = getConfig().getString("flick.block", "CHERRY_PLANKS");
        Material mat = Material.matchMaterial(name);
        return (mat != null && mat.isBlock() && !mat.isAir()) ? mat : Material.CHERRY_PLANKS;
    }

    public void setFlickBlockMaterial(Material mat) {
        getConfig().set("flick.block", mat.name());
        saveConfig();
    }

    public String getProgressRewardCommand(TrainerType type) {
        return getConfig().getString("progress-rewards." + type.name(), "");
    }

    public void setProgressRewardCommand(TrainerType type, String command) {
        getConfig().set("progress-rewards." + type.name(), command);
        saveConfig();
    }

    public PlayerDataStore getDataStore() {
        return dataStore;
    }

    public SessionManager getSessionManager() {
        return sessionManager;
    }
}
