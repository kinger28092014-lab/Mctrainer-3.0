package ru.pluginteam.mctrainer.session;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import ru.pluginteam.mctrainer.model.TrackingTarget;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.arena.ArenaBuilder;
import ru.pluginteam.mctrainer.model.Difficulty;
import ru.pluginteam.mctrainer.model.ProgressLevel;
import ru.pluginteam.mctrainer.model.SessionOptions;
import ru.pluginteam.mctrainer.model.TrainerType;

import java.time.Duration;
import java.util.*;

public class TrainingSession {
    private final MCTrainerPlugin plugin;
    private final Player player;
    private final SessionOptions options;
    private final PlayerSnapshot snapshot;
    private final Location center;
    private final int slotIndex;
    private int arenaRadius = 12;

    private BukkitTask mainTask;
    private boolean finished = false;
    private int ticksElapsed = 0;
    private int timeLeftSeconds;

    // Общая статистика
    private int hits = 0;
    private int misses = 0;
    private int currentStreak = 0;
    private int bestStreak = 0;

    // Tracking: стойка / флаг / спешик, стрейфы, резкие движения, прохождение сквозь игрока
    private Entity trackingEntity;
    private Location trackingPos;
    private Location trackingTargetPos;
    private int trackingMoveTicksLeft = 0;
    private boolean trackingPassThroughNext = false;
    private boolean trackingCurrentlyGreen = false;
    private int trackingOnTargetTicks = 0;
    private int trackingTotalTicks = 0;
    private ItemStack[] greenArmor;
    private ItemStack[] redArmor;

    // Flick: настраиваемая дальность + таймер исчезновения блоков + кастомный блок
    private static class FlickTarget {
        final BlockDisplay display;
        final int expiresAtTick;
        FlickTarget(BlockDisplay display, int expiresAtTick) {
            this.display = display;
            this.expiresAtTick = expiresAtTick;
        }
    }
    private final Map<Location, FlickTarget> flickTargets = new HashMap<>();
    private int flickDistance;
    private int flickLifetimeTicks;

    // Clutch
    private int clutchDropsDone = 0;
    private int clutchSuccesses = 0;
    private int clutchHeight;
    private boolean clutchFalling = false;
    private boolean clutchWaitingReset = false;
    private Location placedWaterLoc = null;

    // StunSlam
    private Zombie stunNpc;
    private boolean npcShieldUp = true;
    private boolean shieldBrokenThisJump = false;
    private boolean slamCompletedThisJump = false;
    private boolean inJump = false;

    // Pearl Aim
    private Zombie pearlNpc;

    // Anchor Trainer
    private boolean anchorTimerStarted = false;
    private int anchorsExploded = 0;

    // Bot trainers (Mace, Crystal, Sword)
    private Zombie botNpc;
    private double maceAngle = 0.0;
    private int botStrafeDir = 1;
    private int botStrafeTimer = 0;

    private final Random random = new Random();

    public TrainingSession(MCTrainerPlugin plugin, Player player, SessionOptions options, Location center, int slotIndex) {
        this.plugin = plugin;
        this.player = player;
        this.options = options;
        this.snapshot = new PlayerSnapshot(player);
        this.center = center;
        this.slotIndex = slotIndex;

        if (options.getProgressLevel() > 0) {
            options.setDifficulty(ProgressLevel.getDifficultyForLevel(options.getProgressLevel()));
            options.setInfinite(false);
            if (options.getType() == TrainerType.CLUTCH) {
                options.setClutchHeight(ProgressLevel.getClutchHeightForLevel(options.getProgressLevel()));
            }
            if (options.getType() == TrainerType.FLICK) {
                options.setFlickDistance(ProgressLevel.getFlickDistanceForLevel(options.getProgressLevel()));
            }
        }

        this.clutchHeight = options.getClutchHeight();
        this.flickDistance = options.getFlickDistance();
        this.flickLifetimeTicks = options.getProgressLevel() > 0
                ? ProgressLevel.getFlickLifetimeTicksForLevel(options.getProgressLevel())
                : options.getDifficulty().getFlickLifetimeTicks();
        this.timeLeftSeconds = options.getType() == TrainerType.ANCHOR ? 15 : 60;
    }

    public void start() {
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.getInventory().setItemInOffHand(null);
        player.setHealth(20.0);
        player.setFoodLevel(20);
        player.setFallDistance(0f);
        player.setFireTicks(0);
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));

        switch (options.getType()) {
            case TRACKING -> setupTracking();
            case FLICK -> setupFlick();
            case CLUTCH -> setupClutch();
            case STUNSLAM -> setupStunSlam();
            case PEARL_AIM -> setupPearlAim();
            case ANCHOR -> setupAnchor();
            case MACE, CRYSTAL, SWORD -> setupBotTrainer();
        }

        if (options.getProgressLevel() > 0) {
            player.sendMessage("§6[Прогресс] §eУровень " + options.getProgressLevel() + "/" + ProgressLevel.MAX_LEVEL +
                    " §7— Цель: §a" + ProgressLevel.getGoalDescription(options.getType(), options.getProgressLevel()));
        }

        mainTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (finished || !player.isOnline()) {
                    cancel();
                    return;
                }
                tick();
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private ItemStack[] makeColoredArmor(Color color) {
        ItemStack[] armor = new ItemStack[]{
                new ItemStack(Material.LEATHER_BOOTS),
                new ItemStack(Material.LEATHER_LEGGINGS),
                new ItemStack(Material.LEATHER_CHESTPLATE),
                new ItemStack(Material.LEATHER_HELMET)
        };
        for (ItemStack piece : armor) {
            LeatherArmorMeta meta = (LeatherArmorMeta) piece.getItemMeta();
            meta.setColor(color);
            piece.setItemMeta(meta);
        }
        return armor;
    }

    private void setupTracking() {
        arenaRadius = 11;
        ArenaBuilder.buildBoxArena(center, arenaRadius, 16, Material.SMOOTH_STONE, Material.BLACK_STAINED_GLASS, true);
        player.setGameMode(GameMode.ADVENTURE);
        Location pSpawn = center.clone().add(0.5, 0.5, 0.5);
        pSpawn.setYaw(0f);
        pSpawn.setPitch(0f);
        player.teleport(pSpawn);

        greenArmor = makeColoredArmor(Color.LIME);
        redArmor = makeColoredArmor(Color.RED);
        trackingPos = center.clone().add(0.5, 0.5, 5.5);
        pickNextTrackingWaypoint();

        TrackingTarget targetType = options.getTrackingTarget();
        if (targetType == TrackingTarget.ARMOR_STAND) {
            trackingEntity = center.getWorld().spawn(trackingPos, ArmorStand.class, stand -> {
                stand.setGravity(false);
                stand.setMarker(true);
                stand.setInvulnerable(true);
                stand.setArms(true);
                stand.setBasePlate(false);
                stand.setGlowing(true);
                stand.getEquipment().setArmorContents(redArmor);
                stand.customName(Component.text("§c● Цель"));
                stand.setCustomNameVisible(true);
            });
        } else if (targetType == TrackingTarget.BANNER) {
            trackingEntity = center.getWorld().spawn(trackingPos, BlockDisplay.class, disp -> {
                disp.setBlock(Material.RED_BANNER.createBlockData());
                disp.setGlowing(true);
                disp.setGlowColorOverride(Color.RED);
            });
        } else {
            trackingEntity = center.getWorld().spawn(trackingPos, Allay.class, allay -> {
                allay.setAI(false);
                allay.setGravity(false);
                allay.setSilent(true);
                allay.setInvulnerable(true);
                allay.setCollidable(false);
                allay.setGlowing(true);
                allay.getEquipment().setItemInMainHand(new ItemStack(Material.RED_WOOL));
                allay.customName(Component.text("§c● Спешик"));
                allay.setCustomNameVisible(true);
            });
        }

        trackingCurrentlyGreen = false;
        double spd = getEffectiveTrackingSpeed();
        player.sendMessage("§b[Tracking] §7Цель: " + targetType.getDisplayName() + " §7| Скорость: §e" + spd + " §7(Зелёный = в прицеле, Красный = мимо).");
    }

    private double getEffectiveTrackingSpeed() {
        if (options.getProgressLevel() > 0) {
            // В режиме Прогресс скорость плавно растёт от 0.08 до 0.45
            return Math.round((0.05 + options.getProgressLevel() * 0.04) * 100.0) / 100.0;
        }
        return options.getTrackingSpeed();
    }

    private void pickNextTrackingWaypoint() {
        // Каждое 3-е движение проходит прямо сквозь игрока!
        if (trackingPassThroughNext) {
            trackingPassThroughNext = false;
            Vector fromCenter = trackingPos.toVector().subtract(center.clone().add(0.5, 0.5, 0.5).toVector());
            if (fromCenter.lengthSquared() < 1.0) {
                fromCenter = new Vector(4.0, 0, 0);
            }
            // Пролетаем через центр на противоположную сторону
            Vector opposite = fromCenter.normalize().multiply(-5.5);
            double y = 0.5 + random.nextDouble() * 2.2;
            trackingTargetPos = center.clone().add(0.5 + opposite.getX(), y, 0.5 + opposite.getZ());
        } else {
            if (random.nextInt(3) == 0) trackingPassThroughNext = true;
            // Стрейф в случайную точку вокруг игрока на расстоянии 3.5..6.5 блоков
            double angle = random.nextDouble() * Math.PI * 2.0;
            double dist = 3.5 + random.nextDouble() * 3.0;
            double y = 0.5 + random.nextDouble() * 2.5;
            trackingTargetPos = center.clone().add(0.5 + Math.cos(angle) * dist, y, 0.5 + Math.sin(angle) * dist);
        }

        // Чем выше уровень/скорость, тем чаще резкие смены направления
        int sharpFactor = options.getProgressLevel() > 0 ? options.getProgressLevel() : (int) (options.getTrackingSpeed() * 18);
        int maxTicks = Math.max(12, 48 - sharpFactor * 3);
        trackingMoveTicksLeft = 10 + random.nextInt(maxTicks);
    }

    private void setupFlick() {
        arenaRadius = Math.max(12, flickDistance + 3);
        ArenaBuilder.buildBoxArena(center, arenaRadius, 14, Material.SMOOTH_STONE, Material.GRAY_CONCRETE, true);
        player.setGameMode(GameMode.ADVENTURE);
        Location spawn = center.clone().add(0.5, 0.5, 2.5);
        spawn.setYaw(180f);
        spawn.setPitch(0f);
        player.teleport(spawn);
        player.getInventory().setItem(0, new ItemStack(Material.IRON_SWORD));

        for (int i = 0; i < 3; i++) {
            spawnFlickTarget();
        }
        player.sendMessage("§e[Flick] §7Дальность: §b" + flickDistance + " бл. §7| Время жизни блока: §e" + String.format("%.1f", flickLifetimeTicks / 20.0) + "с");
    }

    private void spawnFlickTarget() {
        World w = center.getWorld();
        Material mat = plugin.getFlickBlockMaterial();
        int targetZ = center.getBlockZ() + 2 - flickDistance;
        for (int attempt = 0; attempt < 30; attempt++) {
            int dx = random.nextInt(11) - 5;
            int dy = random.nextInt(6) + 1;
            Location loc = new Location(w, center.getBlockX() + dx, center.getBlockY() + dy, targetZ);
            if (!flickTargets.containsKey(loc)) {
                loc.getBlock().setType(mat, false);
                BlockDisplay display = w.spawn(loc, BlockDisplay.class, d -> {
                    d.setBlock(mat.createBlockData());
                    d.setGlowing(true);
                    d.setGlowColorOverride(Color.RED);
                });
                flickTargets.put(loc, new FlickTarget(display, ticksElapsed + flickLifetimeTicks));
                return;
            }
        }
    }

    private void setupClutch() {
        arenaRadius = 8;
        ArenaBuilder.buildClutchArena(center, clutchHeight);
        player.setGameMode(GameMode.SURVIVAL);
        resetClutchDrop();
        player.sendMessage("§3[Clutch] §7Высота: §e" + clutchHeight + " бл. §7Выполните §a5 §7успешных ватердропов из §e6 §7падений!");
    }

    public void resetClutchDrop() {
        if (placedWaterLoc != null) {
            placedWaterLoc.getBlock().setType(Material.AIR, false);
            placedWaterLoc = null;
        }
        // Полностью очищаем всю воду на арене клатча, чтобы ни одной капли не осталось
        World w = center.getWorld();
        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();
        for (int x = -arenaRadius + 1; x <= arenaRadius - 1; x++) {
            for (int z = -arenaRadius + 1; z <= arenaRadius - 1; z++) {
                for (int y = 0; y <= 3; y++) {
                    Block b = w.getBlockAt(cx + x, cy + y, cz + z);
                    if (b.getType() == Material.WATER) {
                        b.setType(Material.AIR, false);
                    }
                }
            }
        }
        player.getInventory().clear();
        player.getInventory().setItem(0, new ItemStack(Material.WATER_BUCKET));
        player.setHealth(20.0);
        player.setFallDistance(0f);
        player.setVelocity(new Vector(0, 0, 0));
        Location top = center.clone().add(0.5, clutchHeight, 0.5);
        player.teleport(top);
        clutchFalling = false;
        clutchWaitingReset = false;
    }

    private void setupStunSlam() {
        arenaRadius = 10;
        ArenaBuilder.buildBoxArena(center, arenaRadius, 22, Material.SMOOTH_STONE, Material.DEEPSLATE_BRICKS, true);
        player.setGameMode(GameMode.SURVIVAL);
        Location pSpawn = center.clone().add(0.5, 0.5, 4.5);
        pSpawn.setYaw(180f);
        player.teleport(pSpawn);

        player.getInventory().setItem(0, new ItemStack(Material.NETHERITE_AXE));
        player.getInventory().setItem(1, new ItemStack(Material.MACE));

        Location npcLoc = center.clone().add(0.5, 0.5, -1.5);
        stunNpc = spawnNpc(npcLoc, "§6NPC со щитом", true, false);
        npcShieldUp = true;

        player.sendMessage("§6[StunSlam] §7Прыгните, сбейте щит §eтопором §7и ударьте §dбулавой §7в 1 прыжке!");
    }

    private void setupPearlAim() {
        arenaRadius = 22;
        ArenaBuilder.buildBoxArena(center, arenaRadius, 18, Material.SMOOTH_STONE, Material.PURPLE_STAINED_GLASS, true);
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(center.clone().add(0.5, 0.5, 0.5));
        giveInfinitePearls();

        pearlNpc = spawnNpc(getRandomPearlLocation(), "§5Цель (Pearl Aim)", false, false);
        player.sendMessage("§5[Pearl Aim] §7Попадайте эндер-жемчугом в NPC! Сложность: " + options.getDifficulty().getDisplayName());
    }

    private void giveInfinitePearls() {
        ItemStack pearls = new ItemStack(Material.ENDER_PEARL, 16);
        ItemMeta meta = pearls.getItemMeta();
        meta.displayName(Component.text("§5Бесконечный жемчуг"));
        pearls.setItemMeta(meta);
        player.getInventory().setItem(0, pearls);
    }

    private Location getRandomPearlLocation() {
        int minD = options.getDifficulty().getPearlMinDist();
        int maxD = Math.min(20, options.getDifficulty().getPearlMaxDist());
        if (minD >= maxD) minD = Math.max(4, maxD - 4);

        Location pLoc = player.getLocation();
        for (int i = 0; i < 30; i++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double dist = minD + random.nextDouble() * (maxD - minD);
            double x = pLoc.getX() + Math.cos(angle) * dist;
            double z = pLoc.getZ() + Math.sin(angle) * dist;
            x = Math.max(center.getBlockX() - 19, Math.min(center.getBlockX() + 19, x));
            z = Math.max(center.getBlockZ() - 19, Math.min(center.getBlockZ() + 19, z));
            return new Location(center.getWorld(), Math.floor(x) + 0.5, center.getBlockY(), Math.floor(z) + 0.5);
        }
        return center.clone().add(8.5, 0.5, 0.5);
    }

    private void setupAnchor() {
        arenaRadius = 10;
        ArenaBuilder.buildAnchorArena(center);
        player.setGameMode(GameMode.SURVIVAL);
        player.teleport(center.clone().add(0.5, 0.5, 0.5));
        player.getInventory().setItem(0, new ItemStack(Material.RESPAWN_ANCHOR, 64));
        player.getInventory().setItem(1, new ItemStack(Material.GLOWSTONE, 64));
        player.getInventory().setItem(2, new ItemStack(Material.OBSIDIAN, 64));
        player.sendMessage("§c[Anchor Trainer] §7Поставьте первый якорь — пойдёт таймер §e15 секунд§7! Стены защищены.");
    }

    private void setupBotTrainer() {
        arenaRadius = 12;
        Material wall = options.getType() == TrainerType.CRYSTAL ? Material.OBSIDIAN : Material.STONE_BRICKS;
        ArenaBuilder.buildBoxArena(center, arenaRadius, 24, Material.SMOOTH_STONE, wall, true);
        player.setGameMode(GameMode.SURVIVAL);

        if (options.getType() == TrainerType.MACE) {
            player.teleport(center.clone().add(0.5, 0.5, 0.5));
            player.getInventory().setItem(0, new ItemStack(Material.MACE));
            player.getInventory().setItem(1, new ItemStack(Material.WIND_CHARGE, 64));
            botNpc = spawnNpc(center.clone().add(4.5, 0.5, 0.5), "§dБегающий NPC", false, false);
            player.sendMessage("§d[Mace Trainer] §7Вас автоматически подкидывает вверх! Попадайте булавой по бегающему вокруг NPC!");
        } else if (options.getType() == TrainerType.CRYSTAL) {
            player.teleport(center.clone().add(0.5, 0.5, 5.5));
            player.getInventory().setItem(0, new ItemStack(Material.OBSIDIAN, 64));
            player.getInventory().setItem(1, new ItemStack(Material.END_CRYSTAL, 64));
            player.getInventory().setItem(2, new ItemStack(Material.RESPAWN_ANCHOR, 64));
            player.getInventory().setItem(3, new ItemStack(Material.GLOWSTONE, 64));
            botNpc = spawnNpc(center.clone().add(0.5, 0.5, -3.5), "§4Crystal NPC", false, false);
            player.sendMessage("§4[Crystal Trainer] §7Тренируйте кристаллы! Стены арены неразрушимы.");
        } else {
            player.teleport(center.clone().add(0.5, 0.5, 5.5));
            player.getInventory().setItem(0, new ItemStack(Material.DIAMOND_SWORD));
            // Для Sword & Combo: бот с физикой, гравитацией и отталкиванием!
            botNpc = spawnNpc(center.clone().add(0.5, 0.5, -3.5), "§aCombo Бот", false, true);
            player.sendMessage("§a[Sword & Combo] §7Бот бегает, стрейфит и отталкивается от ваших ударов!");
        }
    }

    private Zombie spawnNpc(Location loc, String name, boolean withShield, boolean allowKnockback) {
        return loc.getWorld().spawn(loc, Zombie.class, z -> {
            z.setAdult();
            z.setShouldBurnInDay(false);
            z.setAI(allowKnockback);
            z.setSilent(true);
            z.setGravity(true);
            z.setRemoveWhenFarAway(false);
            z.customName(Component.text(name));
            z.setCustomNameVisible(true);

            AttributeInstance kb = z.getAttribute(Attribute.KNOCKBACK_RESISTANCE);
            if (kb != null) kb.setBaseValue(allowKnockback ? 0.0 : 1.0);
            AttributeInstance mh = z.getAttribute(Attribute.MAX_HEALTH);
            if (mh != null) {
                mh.setBaseValue(1000.0);
                z.setHealth(1000.0);
            }

            z.getEquipment().setHelmet(new ItemStack(Material.IRON_HELMET));
            z.getEquipment().setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
            z.getEquipment().setLeggings(new ItemStack(Material.IRON_LEGGINGS));
            z.getEquipment().setBoots(new ItemStack(Material.IRON_BOOTS));
            if (withShield) {
                z.getEquipment().setItemInOffHand(new ItemStack(Material.SHIELD));
            }
        });
    }

    private void tick() {
        ticksElapsed++;

        // Держим игрока внутри арены (защита от вылета за карту)
        if (options.getType() == TrainerType.ANCHOR || options.getType() == TrainerType.CRYSTAL) {
            Location pLoc = player.getLocation();
            if (Math.abs(pLoc.getX() - center.getX()) > arenaRadius - 0.8
                    || Math.abs(pLoc.getZ() - center.getZ()) > arenaRadius - 0.8
                    || pLoc.getY() < center.getY() - 7) {
                player.teleport(center.clone().add(0.5, 1.0, 0.5));
            }
        }

        if (ticksElapsed % 20 == 0) {
            boolean shouldCountDown = !options.isInfinite()
                    && options.getType() != TrainerType.CLUTCH
                    && (options.getType() != TrainerType.ANCHOR || anchorTimerStarted);
            if (shouldCountDown) {
                timeLeftSeconds--;
                if (timeLeftSeconds <= 0) {
                    finish(false);
                    return;
                }
            }
        }

        switch (options.getType()) {
            case TRACKING -> tickTracking();
            case FLICK -> tickFlick();
            case CLUTCH -> tickClutch();
            case STUNSLAM -> tickStunSlam();
            case PEARL_AIM -> tickPearlAim();
            case ANCHOR -> tickAnchor();
            case MACE -> tickMace();
            case CRYSTAL, SWORD -> tickComboOrCrystal();
        }
    }

    private void tickTracking() {
        if (trackingEntity == null || trackingEntity.isDead()) return;

        // 1. СНАЧАЛА проверяем прицел по текущей позиции (исключает смещение вбок из-за телепорта!)
        trackingTotalTicks++;
        Location eyeLoc = player.getEyeLocation();
        Vector eye = eyeLoc.toVector();
        Vector dir = eyeLoc.getDirection().normalize();

        // Точный хитбокс (BoundingBox) ровно по центру видимой модели цели
        TrackingTarget tType = options.getTrackingTarget();
        double cx = trackingPos.getX() + (tType == TrackingTarget.BANNER ? 0.5 : 0.0);
        double cy = trackingPos.getY();
        double cz = trackingPos.getZ() + (tType == TrackingTarget.BANNER ? 0.5 : 0.0);

        BoundingBox hitbox;
        if (tType == TrackingTarget.ALLAY) {
            hitbox = new BoundingBox(cx - 0.45, cy - 0.1, cz - 0.45, cx + 0.45, cy + 0.95, cz + 0.45);
        } else if (tType == TrackingTarget.BANNER) {
            hitbox = new BoundingBox(cx - 0.55, cy, cz - 0.55, cx + 0.55, cy + 1.9, cz + 0.55);
        } else {
            hitbox = new BoundingBox(cx - 0.50, cy, cz - 0.50, cx + 0.50, cy + 2.0, cz + 0.50);
        }

        RayTraceResult hit = hitbox.rayTrace(eye, dir, 30.0);
        boolean onTarget = (hit != null);

        // Переключение цвета: зелёный при наведении, красный без
        if (onTarget != trackingCurrentlyGreen) {
            trackingCurrentlyGreen = onTarget;
            if (trackingEntity instanceof ArmorStand stand) {
                stand.getEquipment().setArmorContents(onTarget ? greenArmor : redArmor);
                stand.customName(Component.text(onTarget ? "§a● В прицеле" : "§c● Цель"));
            } else if (trackingEntity instanceof BlockDisplay disp) {
                disp.setBlock((onTarget ? Material.LIME_BANNER : Material.RED_BANNER).createBlockData());
                disp.setGlowColorOverride(onTarget ? Color.LIME : Color.RED);
            } else if (trackingEntity instanceof Allay allay) {
                allay.getEquipment().setItemInMainHand(new ItemStack(onTarget ? Material.LIME_WOOL : Material.RED_WOOL));
                allay.customName(Component.text(onTarget ? "§a● В прицеле" : "§c● Спешик"));
            }
        }

        if (onTarget) {
            trackingOnTargetTicks++;
            if (trackingOnTargetTicks % 4 == 0) {
                hits++;
                currentStreak++;
                if (currentStreak > bestStreak) bestStreak = currentStreak;
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.3f, 1.8f);
            }
        } else {
            if (trackingTotalTicks % 10 == 0) {
                misses++;
                currentStreak = 0;
            }
        }

        // 2. ПОСЛЕ проверки прицела двигаем цель (стрейфы + резкие рывки + проход сквозь игрока)
        double speed = getEffectiveTrackingSpeed();
        trackingMoveTicksLeft--;
        Vector toWaypoint = trackingTargetPos.toVector().subtract(trackingPos.toVector());
        double distToWp = toWaypoint.length();
        if (distToWp <= speed * 1.5 || trackingMoveTicksLeft <= 0) {
            pickNextTrackingWaypoint();
            toWaypoint = trackingTargetPos.toVector().subtract(trackingPos.toVector());
            distToWp = toWaypoint.length();
        }
        if (distToWp > 0.01) {
            Vector step = toWaypoint.normalize().multiply(Math.min(speed, distToWp));
            trackingPos.add(step);
            // Разворачиваем цель лицом к игроку (для стойки и спешика)
            if (tType != TrackingTarget.BANNER) {
                Vector look = player.getLocation().toVector().subtract(trackingPos.toVector()).setY(0);
                if (look.lengthSquared() > 0.01) trackingPos.setDirection(look);
            }
            trackingEntity.teleport(trackingPos);
        }

        int pct = trackingTotalTicks > 0 ? (int) ((trackingOnTargetTicks * 100.0) / trackingTotalTicks) : 0;
        String timeStr = options.isInfinite() ? "∞" : timeLeftSeconds + "с";
        player.sendActionBar(Component.text("§bТочность: §a" + pct + "% §7| §eОчки: §f" + hits + " §7| §6Серия: §f" + currentStreak + " §7| §7Время: §f" + timeStr));
    }

    private void tickFlick() {
        // Проверка истечения времени жизни блоков
        List<Location> expired = new ArrayList<>();
        for (Map.Entry<Location, FlickTarget> entry : flickTargets.entrySet()) {
            if (ticksElapsed >= entry.getValue().expiresAtTick) {
                expired.add(entry.getKey());
            }
        }
        for (Location loc : expired) {
            FlickTarget ft = flickTargets.remove(loc);
            if (ft != null && ft.display != null) ft.display.remove();
            loc.getBlock().setType(Material.AIR, false);
            misses++;
            currentStreak = 0;
            spawnFlickTarget();
        }

        String timeStr = options.isInfinite() ? "∞" : timeLeftSeconds + "с";
        player.sendActionBar(Component.text("§aПопадания: §f" + hits + " §7| §cПромахи: §f" + misses + " §7| §6Серия: §f" + currentStreak + " §7| §7Время: §f" + timeStr));
    }

    private void tickClutch() {
        if (clutchWaitingReset) {
            player.sendActionBar(Component.text("§3Падение: §e" + Math.min(6, clutchDropsDone + 1) + "/6 §7| §aУспешно: §f" + clutchSuccesses + "/5 §7| §6Серия: §f" + currentStreak + " §7| §7Высота: §b" + clutchHeight));
            return;
        }
        if (player.getLocation().getY() < center.getBlockY() + clutchHeight - 2.0) {
            clutchFalling = true;
        }
        if (clutchFalling && player.getLocation().getY() <= center.getBlockY() + 1.2) {
            Material feet = player.getLocation().getBlock().getType();
            Material below = player.getLocation().clone().subtract(0, 0.3, 0).getBlock().getType();
            if (feet == Material.WATER || below == Material.WATER) {
                handleClutchResult(true);
            } else if (player.isOnGround() && player.getFallDistance() == 0f) {
                handleClutchResult(false);
            }
        }
        player.sendActionBar(Component.text("§3Падение: §e" + (clutchDropsDone + 1) + "/6 §7| §aУспешно: §f" + clutchSuccesses + "/5 §7| §6Серия: §f" + currentStreak + " §7| §7Высота: §b" + clutchHeight));
    }

    public void handleClutchResult(boolean success) {
        if (!clutchFalling || clutchWaitingReset || finished) return;
        clutchFalling = false;
        clutchWaitingReset = true;
        clutchDropsDone++;

        if (success) {
            clutchSuccesses++;
            hits++;
            currentStreak++;
            if (currentStreak > bestStreak) bestStreak = currentStreak;
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
            player.sendMessage("§a✔ Клатч выполнен! (" + clutchSuccesses + "/5)");
        } else {
            misses++;
            currentStreak = 0;
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            player.sendMessage("§c✘ Промах!");
        }

        if (currentStreak >= 5) {
            int currentRec = plugin.getDataStore().getRecommendedClutchHeight(player.getUniqueId());
            int newRec = Math.max(currentRec, clutchHeight + 5);
            if (newRec > currentRec) {
                plugin.getDataStore().setRecommendedClutchHeight(player.getUniqueId(), newRec);
                player.sendMessage("§b★ 5 клатчей подряд! Новая рекомендуемая высота: §e" + newRec + " блоков!");
            }
        }

        if (clutchSuccesses >= 5 || clutchDropsDone >= 6) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> finish(false), 15L);
        } else {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!finished) resetClutchDrop();
            }, 15L);
        }
    }

    public void setPlacedWaterLoc(Location loc) {
        this.placedWaterLoc = loc;
    }

    private void tickStunSlam() {
        if (stunNpc != null && !stunNpc.isDead()) {
            Location npcLoc = stunNpc.getLocation();
            Vector dir = player.getLocation().toVector().subtract(npcLoc.toVector());
            npcLoc.setDirection(dir);
            stunNpc.teleport(npcLoc);
        }

        if (inJump && player.isOnGround() && player.getVelocity().getY() <= 0) {
            inJump = false;
            if (!slamCompletedThisJump && shieldBrokenThisJump) {
                misses++;
                currentStreak = 0;
            }
            shieldBrokenThisJump = false;
            slamCompletedThisJump = false;
        }

        String timeStr = options.isInfinite() ? "∞" : timeLeftSeconds + "с";
        player.sendActionBar(Component.text("§6Серия StunSlam: §e" + currentStreak + " §7| §aУдары: §f" + hits + " §7| §bМакс. серия: §f" + bestStreak + " §7| §7Время: §f" + timeStr));
    }

    public void handleStunSlamJump() {
        if (finished || options.getType() != TrainerType.STUNSLAM) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!finished && player.isOnline()) {
                Vector vel = player.getVelocity();
                vel.setY(1.22);
                player.setVelocity(vel);
                player.playSound(player.getLocation(), Sound.ENTITY_WIND_CHARGE_WIND_BURST, 0.8f, 1.1f);
                inJump = true;
                shieldBrokenThisJump = false;
                slamCompletedThisJump = false;
            }
        });
    }

    public void handleStunSlamHit(Entity target) {
        if (finished || stunNpc == null || !target.getUniqueId().equals(stunNpc.getUniqueId())) return;
        Material hand = player.getInventory().getItemInMainHand().getType();

        if (hand.name().endsWith("_AXE") && npcShieldUp) {
            npcShieldUp = false;
            shieldBrokenThisJump = true;
            stunNpc.getEquipment().setItemInOffHand(null);
            player.playSound(player.getLocation(), Sound.ITEM_SHIELD_BREAK, 1f, 1f);

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!finished && stunNpc != null && !stunNpc.isDead()) {
                    npcShieldUp = true;
                    stunNpc.getEquipment().setItemInOffHand(new ItemStack(Material.SHIELD));
                }
            }, 10L);
            return;
        }

        if (hand == Material.MACE && shieldBrokenThisJump && !slamCompletedThisJump && inJump) {
            slamCompletedThisJump = true;
            hits++;
            currentStreak++;
            if (currentStreak > bestStreak) bestStreak = currentStreak;
            player.playSound(player.getLocation(), Sound.ITEM_MACE_SMASH_GROUND, 1f, 1.1f);
            player.showTitle(Title.title(
                    Component.text("§6§lStunslame!"),
                    Component.text("§eСерия: " + currentStreak),
                    Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(700), Duration.ofMillis(200))
            ));
        } else if (hand == Material.MACE && npcShieldUp) {
            misses++;
            currentStreak = 0;
            player.playSound(player.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 1f);
        }
    }

    private void tickPearlAim() {
        if (pearlNpc != null && !pearlNpc.isDead()) {
            Location loc = pearlNpc.getLocation();
            loc.setDirection(player.getLocation().toVector().subtract(loc.toVector()));
            pearlNpc.teleport(loc);
        }
        String timeStr = options.isInfinite() ? "∞" : timeLeftSeconds + "с";
        player.sendActionBar(Component.text("§aПопадания: §f" + hits + " §7| §cПромахи: §f" + misses + " §7| §6Серия: §f" + currentStreak + " §7| §7Время: §f" + timeStr));
    }

    public void handlePearlImpact(Location impactLoc, Entity hitEntity) {
        if (finished || options.getType() != TrainerType.PEARL_AIM || pearlNpc == null) return;
        giveInfinitePearls();

        boolean hit = (hitEntity != null && hitEntity.getUniqueId().equals(pearlNpc.getUniqueId()))
                || (impactLoc.getWorld().equals(pearlNpc.getWorld())
                && impactLoc.distance(pearlNpc.getLocation().clone().add(0, 1.0, 0)) <= 1.65);

        if (hit) {
            hits++;
            currentStreak++;
            if (currentStreak > bestStreak) bestStreak = currentStreak;
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.5f);
            pearlNpc.teleport(getRandomPearlLocation());
        } else {
            misses++;
            currentStreak = 0;
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1.2f);
        }
    }

    private void tickAnchor() {
        String status = anchorTimerStarted ? ("§cОсталось: §e" + timeLeftSeconds + "с") : "§7Поставьте первый якорь...";
        player.sendActionBar(Component.text("§cВзорвано якорей: §e" + anchorsExploded + " §7| " + status));
    }

    public void handleAnchorPlaced() {
        if (!anchorTimerStarted) {
            anchorTimerStarted = true;
            player.sendMessage("§c[Anchor Trainer] §eТаймер 15 секунд пошёл! Взрывайте якоря!");
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
        }
    }

    public void handleAnchorExploded() {
        anchorsExploded++;
        hits++;
        currentStreak++;
        if (currentStreak > bestStreak) bestStreak = currentStreak;
        if (!player.getInventory().contains(Material.RESPAWN_ANCHOR, 16)) {
            player.getInventory().addItem(new ItemStack(Material.RESPAWN_ANCHOR, 32));
        }
        if (!player.getInventory().contains(Material.GLOWSTONE, 16)) {
            player.getInventory().addItem(new ItemStack(Material.GLOWSTONE, 32));
        }
    }

    // Mace: игрок стоит на месте (X/Z фиксированы), автоматически подкидывается вверх, NPC бегает вокруг
    private void tickMace() {
        if (player.isOnGround() && player.getVelocity().getY() <= 0.05) {
            Vector vel = player.getVelocity();
            vel.setX(0);
            vel.setZ(0);
            vel.setY(1.25);
            player.setVelocity(vel);
            player.playSound(player.getLocation(), Sound.ENTITY_WIND_CHARGE_WIND_BURST, 0.6f, 1.2f);
        }

        if (botNpc != null && !botNpc.isDead()) {
            maceAngle += options.getDifficulty().getTrackingSpeed() * 1.1;
            double r = 3.2;
            Location next = center.clone().add(0.5 + Math.cos(maceAngle) * r, 0.0, 0.5 + Math.sin(maceAngle) * r);
            next.setDirection(player.getLocation().toVector().subtract(next.toVector()).setY(0));
            botNpc.teleport(next);
        }

        String timeStr = options.isInfinite() ? "∞" : timeLeftSeconds + "с";
        player.sendActionBar(Component.text("§dУдары булавой: §f" + hits + " §7| §6Серия: §f" + currentStreak + " §7| §7Время: §f" + timeStr));
    }

    // Sword & Combo / Crystal: бот бегает по земле, стрейфит и получает реальное отталкивание
    private void tickComboOrCrystal() {
        if (botNpc == null || botNpc.isDead()) return;
        botStrafeTimer++;
        if (botStrafeTimer > 22) {
            botStrafeTimer = 0;
            if (random.nextBoolean()) botStrafeDir = -botStrafeDir;
        }

        // Возврат внутрь арены, если отлетел к стене
        Location bLoc = botNpc.getLocation();
        if (Math.abs(bLoc.getX() - center.getX()) > arenaRadius - 2 || Math.abs(bLoc.getZ() - center.getZ()) > arenaRadius - 2) {
            botStrafeDir = -botStrafeDir;
        }

        if (options.getType() == TrainerType.SWORD) {
            // Движение через velocity только когда бот на земле (не летает и нормально отталкивается!)
            if (botNpc.isOnGround() && botNpc.getNoDamageTicks() <= 5) {
                Vector toPlayer = player.getLocation().toVector().subtract(bLoc.toVector()).setY(0);
                double dist = toPlayer.length();
                if (dist > 0.1) {
                    toPlayer.normalize();
                    Vector strafe = new Vector(-toPlayer.getZ(), 0, toPlayer.getX()).multiply(botStrafeDir);
                    Vector move = strafe.multiply(0.75);
                    if (dist > 3.8) move.add(toPlayer.clone().multiply(0.6));
                    else if (dist < 2.2) move.add(toPlayer.clone().multiply(-0.4));
                    move.normalize().multiply(options.getDifficulty().getBotSpeed());
                    Vector cur = botNpc.getVelocity();
                    botNpc.setVelocity(new Vector(move.getX(), cur.getY(), move.getZ()));
                }
            }
        } else {
            // Crystal NPC
            Vector toPlayer = player.getLocation().toVector().subtract(bLoc.toVector()).setY(0);
            if (toPlayer.lengthSquared() > 0.01) {
                toPlayer.normalize();
                Vector strafe = new Vector(-toPlayer.getZ(), 0, toPlayer.getX()).multiply(botStrafeDir * options.getDifficulty().getBotSpeed());
                Location next = bLoc.clone().add(strafe);
                if (Math.abs(next.getX() - center.getX()) < arenaRadius - 2 && Math.abs(next.getZ() - center.getZ()) < arenaRadius - 2) {
                    next.setDirection(toPlayer);
                    botNpc.teleport(next);
                }
            }
        }

        String timeStr = options.isInfinite() ? "∞" : timeLeftSeconds + "с";
        player.sendActionBar(Component.text("§aУдары: §f" + hits + " §7| §6Серия: §f" + currentStreak + " §7| §7Время: §f" + timeStr));
    }

    public void handleBotHit(Entity target) {
        if (finished || botNpc == null || !target.getUniqueId().equals(botNpc.getUniqueId())) return;
        hits++;
        currentStreak++;
        if (currentStreak > bestStreak) bestStreak = currentStreak;
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.4f);

        // Явное отталкивание в Sword & Combo
        if (options.getType() == TrainerType.SWORD) {
            Vector kb = botNpc.getLocation().toVector().subtract(player.getLocation().toVector()).setY(0);
            if (kb.lengthSquared() > 0.01) {
                kb.normalize().multiply(0.55).setY(0.32);
                botNpc.setVelocity(kb);
            }
        }
    }

    public void handleFlickClick() {
        if (finished || options.getType() != TrainerType.FLICK) return;
        Block hitBlock = player.getTargetBlockExact(25);
        if (hitBlock != null && flickTargets.containsKey(hitBlock.getLocation())) {
            Location loc = hitBlock.getLocation();
            FlickTarget ft = flickTargets.remove(loc);
            if (ft != null && ft.display != null) ft.display.remove();
            loc.getBlock().setType(Material.AIR, false);

            hits++;
            currentStreak++;
            if (currentStreak > bestStreak) bestStreak = currentStreak;
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 1.8f);
            spawnFlickTarget();
        } else {
            misses++;
            currentStreak = 0;
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.4f, 1.2f);
        }
    }

    public boolean isInsideArena(Block b) {
        if (!b.getWorld().equals(center.getWorld())) return false;
        int dx = Math.abs(b.getX() - center.getBlockX());
        int dz = Math.abs(b.getZ() - center.getBlockZ());
        return dx <= arenaRadius && dz <= arenaRadius;
    }

    public boolean isWallBlock(Block b) {
        if (!b.getWorld().equals(center.getWorld())) return false;
        int dx = Math.abs(b.getX() - center.getBlockX());
        int dz = Math.abs(b.getZ() - center.getBlockZ());
        return dx >= arenaRadius || dz >= arenaRadius || b.getType() == Material.BEDROCK || b.getType() == Material.BARRIER;
    }

    public void finish(boolean silent) {
        if (finished) return;
        finished = true;
        if (mainTask != null) mainTask.cancel();

        if (trackingEntity != null) trackingEntity.remove();
        if (stunNpc != null) stunNpc.remove();
        if (pearlNpc != null) pearlNpc.remove();
        if (botNpc != null) botNpc.remove();
        for (FlickTarget ft : flickTargets.values()) {
            if (ft.display != null) ft.display.remove();
        }
        flickTargets.clear();

        if (options.getType() == TrainerType.CLUTCH) {
            ArenaBuilder.clearArea(center, 9, 9, -2, clutchHeight + 9);
        } else if (options.getType() == TrainerType.PEARL_AIM) {
            ArenaBuilder.clearArea(center, 23, 23, -2, 19);
        } else if (options.getType() == TrainerType.ANCHOR) {
            ArenaBuilder.clearArea(center, 11, 11, -7, 17);
        } else {
            ArenaBuilder.clearArea(center, arenaRadius + 1, arenaRadius + 1, -2, 25);
        }

        if (player.isOnline()) {
            snapshot.restore(player);
            if (!silent) {
                sendSummary();
            }
        }

        plugin.getSessionManager().removeSoloSession(player.getUniqueId(), slotIndex);
    }

    private void sendSummary() {
        player.sendMessage("§8§m----------------------------------------");
        player.sendMessage("§6§lРезультаты тренировки: " + options.getType().getDisplayName());
        player.sendMessage("§aПопадания / Успехи: §f" + hits);
        player.sendMessage("§cПромахи: §f" + misses);
        player.sendMessage("§eЛучшая серия: §f" + bestStreak);

        if (options.getType() == TrainerType.ANCHOR) {
            player.sendMessage("§cВзорвано якорей: §f" + anchorsExploded);
        } else if (options.getType() == TrainerType.CLUTCH) {
            int rec = plugin.getDataStore().getRecommendedClutchHeight(player.getUniqueId());
            player.sendMessage("§3Клатчей выполнено: §f" + clutchSuccesses + "/5 §7(Рекомендуемая высота: §b" + rec + " бл.§7)");
        }

        if (options.getProgressLevel() > 0) {
            int lvl = options.getProgressLevel();
            int goal = ProgressLevel.getGoalForLevel(options.getType(), lvl);
            int score = options.getType() == TrainerType.CLUTCH ? clutchSuccesses
                    : (options.getType() == TrainerType.ANCHOR ? anchorsExploded : hits);

            if (score >= goal) {
                plugin.getDataStore().unlockNextLevel(player.getUniqueId(), options.getType(), lvl);
                player.sendMessage("§a§l✔ УРОВЕНЬ " + lvl + " ПРОЙДЕН!");

                if (lvl == ProgressLevel.MAX_LEVEL && !plugin.getDataStore().hasClaimedReward(player.getUniqueId(), options.getType())) {
                    plugin.getDataStore().setClaimedReward(player.getUniqueId(), options.getType());
                    String rewardCmd = plugin.getProgressRewardCommand(options.getType());
                    if (rewardCmd != null && !rewardCmd.isBlank()) {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), rewardCmd.replace("%player%", player.getName()));
                    }
                    player.sendMessage("§6§l★ ПОЗДРАВЛЯЕМ! Вы прошли все 10 уровней и получили награду!");
                }

                player.showTitle(Title.title(
                        Component.text("§a§lУровень " + lvl + " пройден!"),
                        Component.text(lvl == ProgressLevel.MAX_LEVEL ? "§6Награда выдана!" : "§eОткрыт уровень " + (lvl + 1) + "!"),
                        Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(2), Duration.ofMillis(500))
                ));
            } else {
                player.sendMessage("§c✘ Уровень " + lvl + " не пройден (§f" + score + "/" + goal + "§c). Попробуйте ещё раз!");
            }
        }
        player.sendMessage("§8§m----------------------------------------");
    }

    public TrainerType getType() { return options.getType(); }
    public boolean isFinished() { return finished; }
    public Location getCenter() { return center; }
    public boolean isHorizontalMovementLocked() {
        return options.getType() == TrainerType.TRACKING || options.getType() == TrainerType.MACE;
    }
}
