package ru.pluginteam.mctrainer.session;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.arena.ArenaBuilder;
import ru.pluginteam.mctrainer.model.TrainerType;

import java.time.Duration;
import java.util.*;

public class DuelSession {
    private final MCTrainerPlugin plugin;
    private final Player p1;
    private final Player p2;
    private final TrainerType type;
    private final PlayerSnapshot snap1;
    private final PlayerSnapshot snap2;
    private final Location center;
    private final int slotIndex;

    private BukkitTask task;
    private boolean finished = false;
    private int ticks = 0;
    private int timeLeft = 60;

    private int score1 = 0;
    private int score2 = 0;

    private ArmorStand stand1;
    private ArmorStand stand2;
    private double angle = 0.0;

    private final Map<Location, BlockDisplay> flick1 = new HashMap<>();
    private final Map<Location, BlockDisplay> flick2 = new HashMap<>();
    private final Random random = new Random();

    public DuelSession(MCTrainerPlugin plugin, Player p1, Player p2, TrainerType type, Location center, int slotIndex) {
        this.plugin = plugin;
        this.p1 = p1;
        this.p2 = p2;
        this.type = type;
        this.snap1 = new PlayerSnapshot(p1);
        this.snap2 = new PlayerSnapshot(p2);
        this.center = center;
        this.slotIndex = slotIndex;
    }

    public void start() {
        ArenaBuilder.buildDoubleDuelArena(center);

        preparePlayer(p1, center.clone().add(-7.5, 0.5, 4.5));
        preparePlayer(p2, center.clone().add(7.5, 0.5, 4.5));

        if (type == TrainerType.TRACKING) {
            stand1 = spawnStand(center.clone().add(-7.5, 1.5, -2.5), "§bЦель " + p1.getName());
            stand2 = spawnStand(center.clone().add(7.5, 1.5, -2.5), "§bЦель " + p2.getName());
        } else {
            p1.getInventory().setItem(0, new ItemStack(Material.IRON_SWORD));
            p2.getInventory().setItem(0, new ItemStack(Material.IRON_SWORD));
            for (int i = 0; i < 3; i++) {
                spawnFlickTarget(true);
                spawnFlickTarget(false);
            }
        }

        String msg = "§6[Дуэль " + type.getDisplayName() + "§6] §aБой начался! У вас 1 минута!";
        p1.sendMessage(msg);
        p2.sendMessage(msg);

        task = new BukkitRunnable() {
            @Override
            public void run() {
                if (finished || !p1.isOnline() || !p2.isOnline()) {
                    finish(false);
                    cancel();
                    return;
                }
                tick();
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void preparePlayer(Player p, Location loc) {
        p.getInventory().clear();
        p.getInventory().setArmorContents(null);
        p.getInventory().setItemInOffHand(null);
        p.setGameMode(GameMode.ADVENTURE);
        p.setHealth(20.0);
        p.setFoodLevel(20);
        loc.setYaw(180f);
        loc.setPitch(0f);
        p.teleport(loc);
    }

    private ArmorStand spawnStand(Location loc, String name) {
        return loc.getWorld().spawn(loc, ArmorStand.class, s -> {
            s.setGravity(false);
            s.setMarker(true);
            s.setInvulnerable(true);
            s.setArms(true);
            s.setBasePlate(false);
            s.getEquipment().setHelmet(new ItemStack(Material.DIAMOND_HELMET));
            s.getEquipment().setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
            s.customName(Component.text(name));
            s.setCustomNameVisible(true);
        });
    }

    private void spawnFlickTarget(boolean isP1) {
        World w = center.getWorld();
        Material mat = plugin.getFlickBlockMaterial();
        Map<Location, BlockDisplay> map = isP1 ? flick1 : flick2;
        int baseX = isP1 ? (center.getBlockX() - 7) : (center.getBlockX() + 7);

        for (int i = 0; i < 30; i++) {
            int dx = random.nextInt(9) - 4;
            int dy = random.nextInt(6) + 1;
            Location loc = new Location(w, baseX + dx, center.getBlockY() + dy, center.getBlockZ() - 5);
            if (!map.containsKey(loc)) {
                loc.getBlock().setType(mat, false);
                BlockDisplay display = w.spawn(loc, BlockDisplay.class, d -> {
                    d.setBlock(mat.createBlockData());
                    d.setGlowing(true);
                    d.setGlowColorOverride(Color.RED);
                });
                map.put(loc, display);
                return;
            }
        }
    }

    private void tick() {
        ticks++;
        if (ticks % 20 == 0) {
            timeLeft--;
            if (timeLeft <= 0) {
                finish(false);
                return;
            }
        }

        if (type == TrainerType.TRACKING) {
            angle += 0.050;
            double x = Math.sin(angle) * 4.5;
            double z = Math.sin(angle * 2.0) * 3.0;
            double y = 1.5 + Math.sin(angle * 1.4) * 2.0;

            stand1.teleport(center.clone().add(-7.5 + x, Math.max(0.5, y), z));
            stand2.teleport(center.clone().add(7.5 + x, Math.max(0.5, y), z));

            if (isAimingAt(p1, stand1) && ticks % 3 == 0) score1++;
            if (isAimingAt(p2, stand2) && ticks % 3 == 0) score2++;
        }

        Component bar = Component.text("§e" + p1.getName() + ": §a" + score1 + " §7vs §e" + p2.getName() + ": §a" + score2 + " §7| §f" + timeLeft + "с");
        p1.sendActionBar(bar);
        p2.sendActionBar(bar);
    }

    private boolean isAimingAt(Player p, ArmorStand stand) {
        Vector eye = p.getEyeLocation().toVector();
        Vector dir = p.getEyeLocation().getDirection().normalize();
        Vector target = stand.getLocation().toVector().add(new Vector(0, 1.0, 0));
        Vector toTarget = target.clone().subtract(eye);
        double dist = toTarget.length();
        double dot = toTarget.normalize().dot(dir);
        double perp = dist * Math.sqrt(Math.max(0, 1.0 - dot * dot));
        return dot > 0 && perp < 0.85;
    }

    public void handleFlickClick(Player clicker) {
        if (finished || type != TrainerType.FLICK) return;
        boolean isP1 = clicker.getUniqueId().equals(p1.getUniqueId());
        Map<Location, BlockDisplay> map = isP1 ? flick1 : flick2;

        Block hit = clicker.getTargetBlockExact(20);
        if (hit != null && map.containsKey(hit.getLocation())) {
            Location loc = hit.getLocation();
            BlockDisplay disp = map.remove(loc);
            if (disp != null) disp.remove();
            loc.getBlock().setType(Material.AIR, false);
            if (isP1) score1++; else score2++;
            clicker.playSound(clicker.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 1.8f);
            spawnFlickTarget(isP1);
        }
    }

    public void finish(boolean silent) {
        if (finished) return;
        finished = true;
        if (task != null) task.cancel();

        if (stand1 != null) stand1.remove();
        if (stand2 != null) stand2.remove();
        for (BlockDisplay d : flick1.values()) d.remove();
        for (BlockDisplay d : flick2.values()) d.remove();
        flick1.clear();
        flick2.clear();

        ArenaBuilder.clearArea(center, 15, 11, -2, 15);

        if (p1.isOnline()) snap1.restore(p1);
        if (p2.isOnline()) snap2.restore(p2);

        if (!silent) {
            String winnerText;
            if (score1 > score2) {
                winnerText = "§a§lПобедитель: " + p1.getName();
            } else if (score2 > score1) {
                winnerText = "§a§lПобедитель: " + p2.getName();
            } else {
                winnerText = "§e§lНичья!";
            }

            Title title = Title.title(
                    Component.text(winnerText),
                    Component.text("§7Счёт: §f" + p1.getName() + " " + score1 + " : " + score2 + " " + p2.getName()),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(3), Duration.ofMillis(500))
            );
            String chatMsg = "§6[Дуэль] " + winnerText + " §7(" + p1.getName() + " §a" + score1 + " §7: §a" + score2 + " §7" + p2.getName() + ")";

            if (p1.isOnline()) { p1.showTitle(title); p1.sendMessage(chatMsg); }
            if (p2.isOnline()) { p2.showTitle(title); p2.sendMessage(chatMsg); }
        }

        plugin.getSessionManager().removeDuelSession(p1.getUniqueId(), p2.getUniqueId(), slotIndex);
    }

    public TrainerType getType() { return type; }
}
