package ru.pluginteam.mctrainer.session;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class PlayerSnapshot {
    private final Location location;
    private final ItemStack[] contents;
    private final ItemStack[] armor;
    private final ItemStack offhand;
    private final GameMode gameMode;
    private final double health;
    private final int foodLevel;

    public PlayerSnapshot(Player player) {
        this.location = player.getLocation().clone();
        this.contents = cloneArray(player.getInventory().getStorageContents());
        this.armor = cloneArray(player.getInventory().getArmorContents());
        this.offhand = player.getInventory().getItemInOffHand().clone();
        this.gameMode = player.getGameMode();
        this.health = player.getHealth();
        this.foodLevel = player.getFoodLevel();
    }

    public void restore(Player player) {
        player.getInventory().clear();
        player.getInventory().setStorageContents(cloneArray(contents));
        player.getInventory().setArmorContents(cloneArray(armor));
        player.getInventory().setItemInOffHand(offhand != null ? offhand.clone() : null);
        player.setGameMode(gameMode);
        player.setHealth(Math.max(1.0, Math.min(20.0, health)));
        player.setFoodLevel(foodLevel);
        player.setFallDistance(0f);
        player.setFireTicks(0);
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        player.teleport(location);
    }

    private static ItemStack[] cloneArray(ItemStack[] arr) {
        if (arr == null) return new ItemStack[0];
        ItemStack[] copy = new ItemStack[arr.length];
        for (int i = 0; i < arr.length; i++) {
            copy[i] = arr[i] != null ? arr[i].clone() : null;
        }
        return copy;
    }
}
