package ru.pluginteam.mctrainer.session;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.model.DuelInvite;
import ru.pluginteam.mctrainer.model.SessionOptions;
import ru.pluginteam.mctrainer.model.TrainerType;

import java.util.*;

public class SessionManager {
    private final MCTrainerPlugin plugin;
    private final Map<UUID, TrainingSession> soloSessions = new HashMap<>();
    private final Map<UUID, DuelSession> duelSessions = new HashMap<>();
    private final Map<UUID, SessionOptions> pendingOptions = new HashMap<>();
    private final Map<UUID, Map<UUID, DuelInvite>> invites = new HashMap<>();
    private final Set<Integer> usedSlots = new HashSet<>();

    public SessionManager(MCTrainerPlugin plugin) {
        this.plugin = plugin;
    }

    public SessionOptions getOrCreateOptions(UUID uuid, TrainerType type) {
        SessionOptions opt = pendingOptions.get(uuid);
        if (opt == null || opt.getType() != type) {
            opt = new SessionOptions(type);
            if (type == TrainerType.CLUTCH) {
                opt.setClutchHeight(plugin.getDataStore().getRecommendedClutchHeight(uuid));
            }
            pendingOptions.put(uuid, opt);
        }
        return opt;
    }

    public SessionOptions getPendingOptions(UUID uuid) {
        return pendingOptions.get(uuid);
    }

    public boolean isBusy(UUID uuid) {
        return soloSessions.containsKey(uuid) || duelSessions.containsKey(uuid);
    }

    public TrainingSession getSoloSession(UUID uuid) {
        return soloSessions.get(uuid);
    }

    public Collection<TrainingSession> getAllSoloSessions() {
        return soloSessions.values();
    }

    public DuelSession getDuelSession(UUID uuid) {
        return duelSessions.get(uuid);
    }

    public void startSoloSession(Player player, SessionOptions options) {
        if (isBusy(player.getUniqueId())) {
            player.sendMessage("§cВы уже находитесь в тренировке! Напишите /leave.");
            return;
        }
        int slot = allocateSlot();
        Location center = getSlotLocation(slot);
        TrainingSession session = new TrainingSession(plugin, player, options, center, slot);
        soloSessions.put(player.getUniqueId(), session);
        session.start();
    }

    public void sendDuelInvite(Player sender, Player target, TrainerType type) {
        if (isBusy(sender.getUniqueId()) || isBusy(target.getUniqueId())) {
            sender.sendMessage("§cОдин из игроков сейчас занят в тренировке или дуэли!");
            return;
        }
        DuelInvite invite = new DuelInvite(sender.getUniqueId(), target.getUniqueId(), type);
        invites.computeIfAbsent(target.getUniqueId(), k -> new HashMap<>()).put(sender.getUniqueId(), invite);

        String cmd = type == TrainerType.TRACKING ? "/tracking accept " : "/flick accept ";
        sender.sendMessage("§aПриглашение на дуэль " + type.getDisplayName() + " §aотправлено игроку §e" + target.getName() + "§a.");

        Component msg = Component.text("§6[Дуэль] §e" + sender.getName() + " §7вызывает вас на дуэль " + type.getDisplayName() + "§7! ")
                .append(Component.text("§a§l[ПРИНЯТЬ]").clickEvent(ClickEvent.runCommand(cmd + sender.getName())));
        target.sendMessage(msg);
    }

    public void acceptDuelInvite(Player target, String senderName, TrainerType type) {
        if (isBusy(target.getUniqueId())) {
            target.sendMessage("§cСначала завершите текущую тренировку (/leave).");
            return;
        }
        Player sender = Bukkit.getPlayerExact(senderName);
        if (sender == null || !sender.isOnline()) {
            target.sendMessage("§cИгрок " + senderName + " не в сети.");
            return;
        }
        Map<UUID, DuelInvite> map = invites.get(target.getUniqueId());
        DuelInvite invite = map != null ? map.remove(sender.getUniqueId()) : null;
        if (invite == null || invite.isExpired() || invite.getType() != type) {
            target.sendMessage("§cПриглашение не найдено или истекло.");
            return;
        }
        if (isBusy(sender.getUniqueId())) {
            target.sendMessage("§cИгрок " + senderName + " уже занят.");
            return;
        }

        int slot = allocateSlot();
        Location center = getSlotLocation(slot);
        DuelSession duel = new DuelSession(plugin, sender, target, type, center, slot);
        duelSessions.put(sender.getUniqueId(), duel);
        duelSessions.put(target.getUniqueId(), duel);
        duel.start();
    }

    public void leaveSession(Player player) {
        TrainingSession solo = soloSessions.get(player.getUniqueId());
        if (solo != null) {
            solo.finish(false);
            return;
        }
        DuelSession duel = duelSessions.get(player.getUniqueId());
        if (duel != null) {
            duel.finish(false);
            return;
        }
        player.sendMessage("§7Вы сейчас не в тренировке.");
    }

    public void removeSoloSession(UUID uuid, int slot) {
        soloSessions.remove(uuid);
        usedSlots.remove(slot);
    }

    public void removeDuelSession(UUID u1, UUID u2, int slot) {
        duelSessions.remove(u1);
        duelSessions.remove(u2);
        usedSlots.remove(slot);
    }

    public void shutdownAll() {
        for (TrainingSession s : new ArrayList<>(soloSessions.values())) {
            s.finish(true);
        }
        for (DuelSession d : new HashSet<>(duelSessions.values())) {
            d.finish(true);
        }
        soloSessions.clear();
        duelSessions.clear();
        usedSlots.clear();
    }

    private int allocateSlot() {
        int i = 0;
        while (usedSlots.contains(i)) i++;
        usedSlots.add(i);
        return i;
    }

    private Location getSlotLocation(int slot) {
        String worldName = plugin.getConfig().getString("auto-platform.world", "world");
        World w = Bukkit.getWorld(worldName);
        if (w == null) w = Bukkit.getWorlds().get(0);
        int baseX = plugin.getConfig().getInt("auto-platform.base-x", 15000);
        int baseY = plugin.getConfig().getInt("auto-platform.base-y", 120);
        int baseZ = plugin.getConfig().getInt("auto-platform.base-z", 15000);
        int spacing = plugin.getConfig().getInt("auto-platform.spacing", 180);
        return new Location(w, baseX + (slot * spacing), baseY, baseZ);
    }
}
