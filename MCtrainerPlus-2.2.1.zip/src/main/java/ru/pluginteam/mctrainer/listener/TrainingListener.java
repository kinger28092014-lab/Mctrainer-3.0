package ru.pluginteam.mctrainer.listener;

import com.destroystokyo.paper.event.player.PlayerJumpEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.RespawnAnchor;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.gui.AdminMenu;
import ru.pluginteam.mctrainer.gui.PracticeMenu;
import ru.pluginteam.mctrainer.gui.ProgressMenu;
import ru.pluginteam.mctrainer.gui.StartConfigMenu;
import ru.pluginteam.mctrainer.model.ProgressLevel;
import ru.pluginteam.mctrainer.model.SessionOptions;
import ru.pluginteam.mctrainer.model.TrainerType;
import ru.pluginteam.mctrainer.session.DuelSession;
import ru.pluginteam.mctrainer.session.TrainingSession;

import java.util.List;

public class TrainingListener implements Listener {
    private final MCTrainerPlugin plugin;

    public TrainingListener(MCTrainerPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        String title = PlainTextComponentSerializer.plainText().serialize(e.getView().title());

        // 0. Админ-меню /mctrainer
        if (title.equals(AdminMenu.TITLE)) {
            e.setCancelled(true);
            if (e.getSlot() == 11) {
                Material hand = player.getInventory().getItemInMainHand().getType();
                if (!hand.isBlock() || hand.isAir()) {
                    player.sendMessage("§cВозьмите любой блок в правую руку!");
                } else {
                    plugin.setFlickBlockMaterial(hand);
                    player.sendMessage("§aБлок для Flick изменён на §e" + hand.name() + "§a!");
                    AdminMenu.open(plugin, player);
                }
            } else if (e.getSlot() == 15) {
                plugin.reloadConfig();
                player.sendMessage("§aКонфиг перезагружен!");
                AdminMenu.open(plugin, player);
            }
            return;
        }

        // 1. Главное меню /practice
        if (title.equals(PracticeMenu.TITLE)) {
            e.setCancelled(true);
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;
            NamespacedKey key = new NamespacedKey(plugin, "trainer_type");
            String typeName = clicked.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
            if (typeName == null) return;
            TrainerType type = TrainerType.valueOf(typeName);
            SessionOptions opt = plugin.getSessionManager().getOrCreateOptions(player.getUniqueId(), type);
            opt.setProgressLevel(0);
            StartConfigMenu.open(plugin, player, opt);
            return;
        }

        // 2. Меню настройки тренировки
        if (title.equals(StartConfigMenu.TITLE)) {
            e.setCancelled(true);
            SessionOptions opt = plugin.getSessionManager().getPendingOptions(player.getUniqueId());
            if (opt == null) return;

            if (e.getSlot() == 22) {
                PracticeMenu.open(plugin, player);
                return;
            }
            if (e.getSlot() == 14) {
                ProgressMenu.open(plugin, player, opt.getType());
                return;
            }
            if (e.getSlot() == 16) {
                opt.setProgressLevel(0);
                player.closeInventory();
                plugin.getSessionManager().startSoloSession(player, opt);
                return;
            }

            if (opt.getType() == TrainerType.CLUTCH) {
                if (e.getSlot() == 10) {
                    opt.setClutchHeight(opt.getClutchHeight() - 5);
                    StartConfigMenu.open(plugin, player, opt);
                } else if (e.getSlot() == 11) {
                    int rec = plugin.getDataStore().getRecommendedClutchHeight(player.getUniqueId());
                    opt.setClutchHeight(rec);
                    StartConfigMenu.open(plugin, player, opt);
                } else if (e.getSlot() == 12) {
                    opt.setClutchHeight(opt.getClutchHeight() + 5);
                    StartConfigMenu.open(plugin, player, opt);
                }
            } else {
                if (e.getSlot() == 10 && opt.getType() == TrainerType.TRACKING) {
                    if (e.getClick() == ClickType.RIGHT || e.getClick() == ClickType.SHIFT_RIGHT) {
                        opt.prevTrackingSpeed();
                    } else {
                        opt.nextTrackingSpeed();
                    }
                    StartConfigMenu.open(plugin, player, opt);
                } else if (e.getSlot() == 11 && opt.getType() == TrainerType.TRACKING) {
                    opt.setTrackingTarget(opt.getTrackingTarget().next());
                    StartConfigMenu.open(plugin, player, opt);
                } else if (e.getSlot() == 10 && opt.getType() != TrainerType.ANCHOR) {
                    opt.setDifficulty(opt.getDifficulty().next());
                    StartConfigMenu.open(plugin, player, opt);
                } else if (e.getSlot() == 11 && opt.getType() == TrainerType.FLICK) {
                    int delta = (e.getClick() == ClickType.RIGHT || e.getClick() == ClickType.SHIFT_RIGHT) ? -2 : 2;
                    opt.setFlickDistance(opt.getFlickDistance() + delta);
                    StartConfigMenu.open(plugin, player, opt);
                } else if (e.getSlot() == 12 && opt.getType() != TrainerType.ANCHOR) {
                    opt.setInfinite(!opt.isInfinite());
                    StartConfigMenu.open(plugin, player, opt);
                }
            }
            return;
        }

        // 3. Меню уровней «Прогресс» (10 уровней)
        if (title.equals(ProgressMenu.TITLE)) {
            e.setCancelled(true);
            SessionOptions opt = plugin.getSessionManager().getPendingOptions(player.getUniqueId());
            if (opt == null) return;

            if (e.getSlot() == 31) {
                StartConfigMenu.open(plugin, player, opt);
                return;
            }

            int[] slots = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24};
            for (int i = 0; i < slots.length; i++) {
                if (e.getSlot() == slots[i]) {
                    int lvl = i + 1;
                    int unlocked = plugin.getDataStore().getUnlockedLevel(player.getUniqueId(), opt.getType());
                    if (lvl > unlocked) {
                        player.sendMessage("§cСначала пройдите уровень " + unlocked + "!");
                        return;
                    }
                    opt.setProgressLevel(lvl);
                    player.closeInventory();
                    plugin.getSessionManager().startSoloSession(player, opt);
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        TrainingSession solo = plugin.getSessionManager().getSoloSession(e.getPlayer().getUniqueId());
        if (solo != null && solo.isHorizontalMovementLocked()) {
            Location from = e.getFrom();
            Location to = e.getTo();
            if (from.getX() != to.getX() || from.getZ() != to.getZ()) {
                // Разрешаем вращение головой и вертикальное подкидывание (Mace), блокируем ходьбу X/Z
                e.setTo(new Location(from.getWorld(), from.getX(), to.getY(), from.getZ(), to.getYaw(), to.getPitch()));
            }
        }
    }

    @EventHandler
    public void onJump(PlayerJumpEvent e) {
        TrainingSession session = plugin.getSessionManager().getSoloSession(e.getPlayer().getUniqueId());
        if (session != null && session.getType() == TrainerType.STUNSLAM) {
            session.handleStunSlamJump();
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        TrainingSession solo = plugin.getSessionManager().getSoloSession(p.getUniqueId());
        DuelSession duel = plugin.getSessionManager().getDuelSession(p.getUniqueId());

        if (e.getAction() == Action.LEFT_CLICK_AIR || e.getAction() == Action.LEFT_CLICK_BLOCK) {
            if (solo != null && solo.getType() == TrainerType.FLICK) {
                e.setCancelled(true);
                solo.handleFlickClick();
                return;
            }
            if (duel != null && duel.getType() == TrainerType.FLICK) {
                e.setCancelled(true);
                duel.handleFlickClick(p);
                return;
            }
        }

        if (solo != null && solo.getType() == TrainerType.ANCHOR && e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            Block b = e.getClickedBlock();
            if (b != null && b.getType() == Material.RESPAWN_ANCHOR) {
                if (b.getBlockData() instanceof RespawnAnchor anchor) {
                    ItemStack hand = e.getItem();
                    boolean holdingGlowstone = hand != null && hand.getType() == Material.GLOWSTONE;
                    if (anchor.getCharges() > 0 && (!holdingGlowstone || anchor.getCharges() >= anchor.getMaximumCharges())) {
                        solo.handleAnchorExploded();
                    }
                }
            }
        }
    }

    // Защита стен арены от взрывов якорей и кристаллов
    @EventHandler
    public void onBlockExplode(BlockExplodeEvent e) {
        protectArenaWalls(e.blockList());
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent e) {
        protectArenaWalls(e.blockList());
    }

    private void protectArenaWalls(List<Block> blocks) {
        blocks.removeIf(b -> {
            for (TrainingSession s : plugin.getSessionManager().getAllSoloSessions()) {
                if ((s.getType() == TrainerType.ANCHOR || s.getType() == TrainerType.CRYSTAL) && s.isWallBlock(b)) {
                    return true;
                }
            }
            return false;
        });
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent e) {
        if (plugin.getSessionManager().isBusy(e.getPlayer().getUniqueId())) {
            TrainingSession solo = plugin.getSessionManager().getSoloSession(e.getPlayer().getUniqueId());
            if (solo == null || solo.getType() != TrainerType.ANCHOR || solo.isWallBlock(e.getBlock())) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent e) {
        TrainingSession solo = plugin.getSessionManager().getSoloSession(e.getPlayer().getUniqueId());
        if (solo != null && solo.getType() == TrainerType.ANCHOR && e.getBlockPlaced().getType() == Material.RESPAWN_ANCHOR) {
            solo.handleAnchorPlaced();
        }
    }

    @EventHandler
    public void onLiquidFlow(BlockFromToEvent e) {
        if (e.getBlock().getType() != Material.WATER) return;
        for (TrainingSession s : plugin.getSessionManager().getAllSoloSessions()) {
            if (s.getType() == TrainerType.CLUTCH && s.isInsideArena(e.getBlock())) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        TrainingSession solo = plugin.getSessionManager().getSoloSession(e.getPlayer().getUniqueId());
        if (solo != null && solo.getType() == TrainerType.CLUTCH && e.getBucket() == Material.WATER_BUCKET) {
            solo.setPlacedWaterLoc(e.getBlock().getLocation());
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) {
            TrainingSession solo = plugin.getSessionManager().getSoloSession(p.getUniqueId());
            DuelSession duel = plugin.getSessionManager().getDuelSession(p.getUniqueId());

            if (solo != null) {
                if (solo.getType() == TrainerType.CLUTCH && e.getCause() == EntityDamageEvent.DamageCause.FALL) {
                    e.setCancelled(true);
                    solo.handleClutchResult(false);
                } else {
                    e.setCancelled(true);
                }
            } else if (duel != null) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onDamageByEntity(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        TrainingSession solo = plugin.getSessionManager().getSoloSession(p.getUniqueId());
        if (solo == null) return;

        if (solo.getType() == TrainerType.STUNSLAM) {
            e.setDamage(0.0);
            solo.handleStunSlamHit(e.getEntity());
        } else if (solo.getType() == TrainerType.MACE || solo.getType() == TrainerType.CRYSTAL || solo.getType() == TrainerType.SWORD) {
            e.setDamage(0.0);
            solo.handleBotHit(e.getEntity());
        }
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent e) {
        if (!(e.getEntity() instanceof EnderPearl pearl)) return;
        if (!(pearl.getShooter() instanceof Player p)) return;
        TrainingSession solo = plugin.getSessionManager().getSoloSession(p.getUniqueId());
        if (solo != null && solo.getType() == TrainerType.PEARL_AIM) {
            solo.handlePearlImpact(pearl.getLocation(), e.getHitEntity());
            pearl.remove();
        }
    }

    @EventHandler
    public void onPearlTeleport(PlayerTeleportEvent e) {
        if (e.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
            TrainingSession solo = plugin.getSessionManager().getSoloSession(e.getPlayer().getUniqueId());
            if (solo != null && solo.getType() == TrainerType.PEARL_AIM) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        if (plugin.getSessionManager().isBusy(e.getPlayer().getUniqueId())) {
            plugin.getSessionManager().leaveSession(e.getPlayer());
        }
    }
}
