package ru.pluginteam.mctrainer.arena;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

public class ArenaBuilder {

    public static void buildBoxArena(Location center, int radius, int height, Material floor, Material wall, boolean ceiling) {
        World w = center.getWorld();
        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();

        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                boolean isEdge = (Math.abs(x) == radius || Math.abs(z) == radius);
                w.getBlockAt(cx + x, cy - 1, cz + z).setType(floor, false);
                for (int y = 0; y <= height; y++) {
                    if (isEdge) {
                        w.getBlockAt(cx + x, cy + y, cz + z).setType(wall, false);
                    } else if (ceiling && y == height) {
                        w.getBlockAt(cx + x, cy + y, cz + z).setType(Material.BARRIER, false);
                    } else {
                        w.getBlockAt(cx + x, cy + y, cz + z).setType(Material.AIR, false);
                    }
                }
            }
        }
    }

    public static void buildClutchArena(Location center, int dropHeight) {
        int radius = 8;
        int totalHeight = dropHeight + 8;
        buildBoxArena(center, radius, totalHeight, Material.SMOOTH_STONE, Material.LIGHT_GRAY_STAINED_GLASS, false);

        World w = center.getWorld();
        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();

        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                w.getBlockAt(cx + x, cy + dropHeight - 1, cz + z).setType(Material.QUARTZ_BLOCK, false);
            }
        }
    }

    public static void buildAnchorArena(Location center) {
        int radius = 10;
        int height = 16;
        World w = center.getWorld();
        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();

        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                boolean isEdge = (Math.abs(x) == radius || Math.abs(z) == radius);
                // Глубокая арена: 6 слоёв разрушаемого пола + бедрок на самом дне
                w.getBlockAt(cx + x, cy - 7, cz + z).setType(Material.BEDROCK, false);
                for (int d = -6; d <= -2; d++) {
                    w.getBlockAt(cx + x, cy + d, cz + z).setType(Material.NETHERRACK, false);
                }
                w.getBlockAt(cx + x, cy - 1, cz + z).setType(Material.STONE_BRICKS, false);

                for (int y = 0; y <= height; y++) {
                    if (isEdge) {
                        w.getBlockAt(cx + x, cy + y, cz + z).setType(Material.OBSIDIAN, false);
                    } else if (y == height) {
                        w.getBlockAt(cx + x, cy + y, cz + z).setType(Material.BARRIER, false);
                    } else {
                        w.getBlockAt(cx + x, cy + y, cz + z).setType(Material.AIR, false);
                    }
                }
            }
        }
    }

    public static void buildDoubleDuelArena(Location center) {
        World w = center.getWorld();
        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();
        int halfX = 14;
        int halfZ = 10;
        int height = 14;

        for (int x = -halfX; x <= halfX; x++) {
            for (int z = -halfZ; z <= halfZ; z++) {
                boolean isOuter = (Math.abs(x) == halfX || Math.abs(z) == halfZ);
                boolean isDivider = (x == 0);
                w.getBlockAt(cx + x, cy - 1, cz + z).setType(isDivider ? Material.SEA_LANTERN : Material.SMOOTH_STONE, false);
                for (int y = 0; y <= height; y++) {
                    if (isOuter) {
                        w.getBlockAt(cx + x, cy + y, cz + z).setType(Material.GRAY_CONCRETE, false);
                    } else if (isDivider) {
                        w.getBlockAt(cx + x, cy + y, cz + z).setType(Material.GLASS, false);
                    } else if (y == height) {
                        w.getBlockAt(cx + x, cy + y, cz + z).setType(Material.BARRIER, false);
                    } else {
                        w.getBlockAt(cx + x, cy + y, cz + z).setType(Material.AIR, false);
                    }
                }
            }
        }
    }

    public static void clearArea(Location center, int radiusX, int radiusZ, int minYOffset, int maxYOffset) {
        World w = center.getWorld();
        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();

        for (int x = -radiusX; x <= radiusX; x++) {
            for (int z = -radiusZ; z <= radiusZ; z++) {
                for (int y = minYOffset; y <= maxYOffset; y++) {
                    w.getBlockAt(cx + x, cy + y, cz + z).setType(Material.AIR, false);
                }
            }
        }
    }
}
