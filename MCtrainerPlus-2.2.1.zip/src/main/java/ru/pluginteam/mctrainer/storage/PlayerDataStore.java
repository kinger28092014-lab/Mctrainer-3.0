package ru.pluginteam.mctrainer.storage;

import org.bukkit.configuration.file.YamlConfiguration;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.model.ProgressLevel;
import ru.pluginteam.mctrainer.model.TrainerType;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class PlayerDataStore {
    private final File file;
    private final YamlConfiguration cfg;

    public PlayerDataStore(MCTrainerPlugin plugin) {
        this.file = new File(plugin.getDataFolder(), "playerdata.yml");
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }
        this.cfg = YamlConfiguration.loadConfiguration(file);
    }

    public int getRecommendedClutchHeight(UUID uuid) {
        return cfg.getInt(uuid + ".clutch.recommended", 20);
    }

    public void setRecommendedClutchHeight(UUID uuid, int height) {
        cfg.set(uuid + ".clutch.recommended", Math.max(10, Math.min(100, height)));
        save();
    }

    public int getUnlockedLevel(UUID uuid, TrainerType type) {
        return cfg.getInt(uuid + ".progress." + type.name(), 1);
    }

    public void unlockNextLevel(UUID uuid, TrainerType type, int completedLevel) {
        int current = getUnlockedLevel(uuid, type);
        if (completedLevel >= current && current < ProgressLevel.MAX_LEVEL) {
            cfg.set(uuid + ".progress." + type.name(), current + 1);
            save();
        }
    }

    public boolean hasClaimedReward(UUID uuid, TrainerType type) {
        return cfg.getBoolean(uuid + ".rewards." + type.name(), false);
    }

    public void setClaimedReward(UUID uuid, TrainerType type) {
        cfg.set(uuid + ".rewards." + type.name(), true);
        save();
    }

    public void save() {
        try {
            cfg.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
