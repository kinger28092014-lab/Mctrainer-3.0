package ru.pluginteam.mctrainer.model;

import org.bukkit.Material;

public enum TrackingTarget {
    ARMOR_STAND("§bСтойка для брони", Material.ARMOR_STAND),
    BANNER("§eФлаг", Material.RED_BANNER),
    ALLAY("§dСпешик", Material.ALLAY_SPAWN_EGG);

    private final String displayName;
    private final Material icon;

    TrackingTarget(String displayName, Material icon) {
        this.displayName = displayName;
        this.icon = icon;
    }

    public String getDisplayName() { return displayName; }
    public Material getIcon() { return icon; }

    public TrackingTarget next() {
        TrackingTarget[] vals = values();
        return vals[(ordinal() + 1) % vals.length];
    }
}
