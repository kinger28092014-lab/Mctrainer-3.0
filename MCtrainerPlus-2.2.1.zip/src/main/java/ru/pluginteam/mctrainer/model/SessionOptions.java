package ru.pluginteam.mctrainer.model;

public class SessionOptions {
    public static final double[] TRACKING_SPEEDS = {0.05, 0.1, 0.15, 0.2, 0.3, 0.5};

    private TrainerType type;
    private Difficulty difficulty = Difficulty.SLOW;
    private boolean infinite = false;
    private int clutchHeight = 20;
    private int flickDistance = 8;
    private int progressLevel = 0;

    // Tracking custom options
    private TrackingTarget trackingTarget = TrackingTarget.ARMOR_STAND;
    private int trackingSpeedIndex = 1; // 0.1 по умолчанию

    public SessionOptions(TrainerType type) {
        this.type = type;
    }

    public TrainerType getType() { return type; }
    public void setType(TrainerType type) { this.type = type; }
    public Difficulty getDifficulty() { return difficulty; }
    public void setDifficulty(Difficulty difficulty) { this.difficulty = difficulty; }
    public boolean isInfinite() { return infinite; }
    public void setInfinite(boolean infinite) { this.infinite = infinite; }
    public int getClutchHeight() { return clutchHeight; }
    public void setClutchHeight(int clutchHeight) { this.clutchHeight = Math.max(8, Math.min(100, clutchHeight)); }
    public int getFlickDistance() { return flickDistance; }
    public void setFlickDistance(int flickDistance) { this.flickDistance = Math.max(4, Math.min(14, flickDistance)); }
    public int getProgressLevel() { return progressLevel; }
    public void setProgressLevel(int progressLevel) { this.progressLevel = progressLevel; }

    public TrackingTarget getTrackingTarget() { return trackingTarget; }
    public void setTrackingTarget(TrackingTarget trackingTarget) { this.trackingTarget = trackingTarget; }
    public double getTrackingSpeed() { return TRACKING_SPEEDS[trackingSpeedIndex]; }
    public void nextTrackingSpeed() { trackingSpeedIndex = (trackingSpeedIndex + 1) % TRACKING_SPEEDS.length; }
    public void prevTrackingSpeed() { trackingSpeedIndex = (trackingSpeedIndex - 1 + TRACKING_SPEEDS.length) % TRACKING_SPEEDS.length; }
}
