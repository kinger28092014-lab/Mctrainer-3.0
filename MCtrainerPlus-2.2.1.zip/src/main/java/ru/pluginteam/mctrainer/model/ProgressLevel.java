package ru.pluginteam.mctrainer.model;

public class ProgressLevel {
    public static final int MAX_LEVEL = 10;

    public static Difficulty getDifficultyForLevel(int level) {
        return switch (level) {
            case 1, 2 -> Difficulty.VERY_SLOW;
            case 3, 4 -> Difficulty.SLOW;
            case 5, 6 -> Difficulty.EASY;
            case 7, 8 -> Difficulty.NORMAL;
            case 9 -> Difficulty.HARD;
            default -> Difficulty.INSANE;
        };
    }

    public static int getClutchHeightForLevel(int level) {
        return 10 + level * 7; // 17..80 блоков
    }

    public static int getFlickDistanceForLevel(int level) {
        return Math.min(14, 4 + level); // 5..14 блоков
    }

    public static int getFlickLifetimeTicksForLevel(int level) {
        return Math.max(18, 72 - (level * 5)); // от 3.35с до 0.9с
    }

    public static int getGoalForLevel(TrainerType type, int level) {
        return switch (type) {
            case TRACKING -> 18 + level * 10;
            case FLICK -> 12 + level * 6;
            case CLUTCH -> 5;
            case STUNSLAM -> 2 + level * 2;
            case PEARL_AIM -> 4 + level * 3;
            case ANCHOR -> 2 + level;
            case MACE, CRYSTAL, SWORD -> 8 + level * 5;
        };
    }

    public static String getGoalDescription(TrainerType type, int level) {
        int goal = getGoalForLevel(type, level);
        return switch (type) {
            case TRACKING -> "Набрать " + goal + " очков слежения";
            case FLICK -> goal + " блоков (дальн. " + getFlickDistanceForLevel(level) + " бл., время " + String.format("%.1f", getFlickLifetimeTicksForLevel(level) / 20.0) + "с)";
            case CLUTCH -> "5/6 ватердропов с высоты " + getClutchHeightForLevel(level) + " бл.";
            case STUNSLAM -> "Сделать " + goal + " StunSlam";
            case PEARL_AIM -> "Попасть жемчугом " + goal + " раз";
            case ANCHOR -> "Взорвать " + goal + " якорей за 15с";
            case MACE, CRYSTAL, SWORD -> "Нанести " + goal + " ударов по боту";
        };
    }
}
