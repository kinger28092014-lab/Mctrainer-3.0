package ru.pluginteam.mctrainer.model;

import org.bukkit.Material;

public enum TrainerType {
    TRACKING("§bTracking", Material.ARMOR_STAND, "Стойка кружит вокруг вас: зелёная при наведении, красная без"),
    FLICK("§eFlick (Gridshot)", Material.TARGET, "Исчезающие блоки с красной обводкой и настройкой дальности"),
    CLUTCH("§3Clutch (Waterdrop)", Material.WATER_BUCKET, "Ватердроп: 5 из 6 падений, умная рекомендация высоты"),
    STUNSLAM("§6StunSlam", Material.MACE, "Сбитие щита топором + удар булавой за 1 прыжок"),
    PEARL_AIM("§5Pearl Aim", Material.ENDER_PEARL, "Попадание бесконечным жемчугом в телепортирующегося NPC"),
    ANCHOR("§cAnchor Trainer", Material.RESPAWN_ANCHOR, "15 секунд на взрыв якорей на глубокой арене"),
    MACE("§dMace Trainer", Material.WIND_CHARGE, "Авто-подкидывание вверх + NPC бегает вокруг вас"),
    CRYSTAL("§4Crystal Trainer", Material.END_CRYSTAL, "Кристаллы, обсидиан и якоря против бота"),
    SWORD("§aSword & Combo", Material.DIAMOND_SWORD, "Бот бегает, стрейфит и отталкивается от ударов");

    private final String displayName;
    private final Material icon;
    private final String description;

    TrainerType(String displayName, Material icon, String description) {
        this.displayName = displayName;
        this.icon = icon;
        this.description = description;
    }

    public String getDisplayName() { return displayName; }
    public Material getIcon() { return icon; }
    public String getDescription() { return description; }
}
