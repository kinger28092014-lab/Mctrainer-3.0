package ru.pluginteam.mctrainer.model;

public enum Difficulty {
    VERY_SLOW("§aОчень медленно", 0.020, 0.014, 5, 10, 0.14, 70),
    SLOW("§2Медленно", 0.032, 0.022, 7, 13, 0.18, 55),
    EASY("§eЛёгкая", 0.048, 0.034, 9, 16, 0.22, 44),
    NORMAL("§6Средняя", 0.070, 0.050, 12, 20, 0.27, 34),
    HARD("§cСложная", 0.100, 0.075, 15, 25, 0.33, 25),
    INSANE("§4Киберспорт", 0.140, 0.105, 18, 30, 0.40, 18);

    private final String displayName;
    private final double trackingSpeed;
    private final double trackingVertical;
    private final int pearlMinDist;
    private final int pearlMaxDist;
    private final double botSpeed;
    private final int flickLifetimeTicks;

    Difficulty(String displayName, double trackingSpeed, double trackingVertical, int pearlMinDist, int pearlMaxDist, double botSpeed, int flickLifetimeTicks) {
        this.displayName = displayName;
        this.trackingSpeed = trackingSpeed;
        this.trackingVertical = trackingVertical;
        this.pearlMinDist = pearlMinDist;
        this.pearlMaxDist = pearlMaxDist;
        this.botSpeed = botSpeed;
        this.flickLifetimeTicks = flickLifetimeTicks;
    }

    public String getDisplayName() { return displayName; }
    public double getTrackingSpeed() { return trackingSpeed; }
    public double getTrackingVertical() { return trackingVertical; }
    public int getPearlMinDist() { return pearlMinDist; }
    public int getPearlMaxDist() { return pearlMaxDist; }
    public double getBotSpeed() { return botSpeed; }
    public int getFlickLifetimeTicks() { return flickLifetimeTicks; }

    public Difficulty next() {
        Difficulty[] vals = values();
        return vals[(ordinal() + 1) % vals.length];
    }
}
