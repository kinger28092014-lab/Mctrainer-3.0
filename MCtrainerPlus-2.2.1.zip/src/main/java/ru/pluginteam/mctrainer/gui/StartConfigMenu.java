package ru.pluginteam.mctrainer.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.model.SessionOptions;
import ru.pluginteam.mctrainer.model.TrainerType;

import java.util.List;

public class StartConfigMenu {
    public static final String TITLE = "§8Настройка тренировки";

    public static void open(MCTrainerPlugin plugin, Player player, SessionOptions opt) {
        Inventory inv = Bukkit.createInventory(null, 27, Component.text(TITLE));

        if (opt.getType() == TrainerType.TRACKING) {
            ItemStack spd = new ItemStack(Material.FEATHER);
            ItemMeta spm = spd.getItemMeta();
            spm.displayName(Component.text("§bСкорость цели: §e" + opt.getTrackingSpeed()));
            spm.lore(List.of(
                    Component.text("§7Доступно: §f0.05 / 0.1 / 0.15 / 0.2 / 0.3 / 0.5"),
                    Component.text("§aЛКМ §7— быстрее | §cПКМ §7— медленнее")
            ));
            spd.setItemMeta(spm);
            inv.setItem(10, spd);

            ItemStack tgt = new ItemStack(opt.getTrackingTarget().getIcon());
            ItemMeta tm = tgt.getItemMeta();
            tm.displayName(Component.text("§eЦель: " + opt.getTrackingTarget().getDisplayName()));
            tm.lore(List.of(
                    Component.text("§7Варианты: §bСтойка §7/ §eФлаг §7/ §dСпешик"),
                    Component.text("§aНажмите, чтобы переключить")
            ));
            tgt.setItemMeta(tm);
            inv.setItem(11, tgt);
        } else if (opt.getType() != TrainerType.CLUTCH && opt.getType() != TrainerType.ANCHOR) {
            ItemStack diff = new ItemStack(Material.CLOCK);
            ItemMeta dm = diff.getItemMeta();
            dm.displayName(Component.text("§eСложность: " + opt.getDifficulty().getDisplayName()));
            dm.lore(List.of(Component.text("§7Нажмите, чтобы переключить скорость / время жизни блоков.")));
            diff.setItemMeta(dm);
            inv.setItem(10, diff);
        }

        // Для Flick: настройка дальности появления блоков (слот 11)
        if (opt.getType() == TrainerType.FLICK) {
            ItemStack dist = new ItemStack(Material.SPYGLASS);
            ItemMeta dsm = dist.getItemMeta();
            dsm.displayName(Component.text("§bДальность блоков: §e" + opt.getFlickDistance() + " бл."));
            dsm.lore(List.of(
                    Component.text("§aЛКМ §7— +2 блока"),
                    Component.text("§cПКМ §7— -2 блока (от 4 до 14)")
            ));
            dist.setItemMeta(dsm);
            inv.setItem(11, dist);
        }

        // Для Clutch: высота падения
        if (opt.getType() == TrainerType.CLUTCH) {
            int rec = plugin.getDataStore().getRecommendedClutchHeight(player.getUniqueId());

            ItemStack minus = new ItemStack(Material.RED_WOOL);
            ItemMeta mm = minus.getItemMeta();
            mm.displayName(Component.text("§c-5 блоков высоты"));
            minus.setItemMeta(mm);
            inv.setItem(10, minus);

            ItemStack heightInfo = new ItemStack(Material.WATER_BUCKET);
            ItemMeta hm = heightInfo.getItemMeta();
            hm.displayName(Component.text("§bВысота падения: §e" + opt.getClutchHeight() + " бл."));
            hm.lore(List.of(
                    Component.text("§7Рекомендуемая высота: §a" + rec + " бл."),
                    Component.text("§eНажмите, чтобы выбрать рекомендуемую!")
            ));
            heightInfo.setItemMeta(hm);
            inv.setItem(11, heightInfo);

            ItemStack plus = new ItemStack(Material.LIME_WOOL);
            ItemMeta pm = plus.getItemMeta();
            pm.displayName(Component.text("§a+5 блоков высоты"));
            plus.setItemMeta(pm);
            inv.setItem(12, plus);
        }

        if (opt.getType() != TrainerType.CLUTCH && opt.getType() != TrainerType.ANCHOR) {
            ItemStack inf = new ItemStack(opt.isInfinite() ? Material.NETHER_STAR : Material.SAND);
            ItemMeta im = inf.getItemMeta();
            im.displayName(Component.text("§bДлительность: " + (opt.isInfinite() ? "§aБесконечно" : "§e1 минута")));
            im.lore(List.of(Component.text("§7Нажмите, чтобы переключить (выход через /leave).")));
            inf.setItemMeta(im);
            inv.setItem(12, inf);
        }

        ItemStack prog = new ItemStack(Material.EXPERIENCE_BOTTLE);
        ItemMeta prm = prog.getItemMeta();
        prm.displayName(Component.text("§6§lРежим «Прогресс» (10 уровней)"));
        prm.lore(List.of(
                Component.text("§7Пройдите все 10 уровней и получите награду!"),
                Component.text("§eНажмите, чтобы открыть уровни")
        ));
        prog.setItemMeta(prm);
        inv.setItem(14, prog);

        ItemStack start = new ItemStack(Material.EMERALD_BLOCK);
        ItemMeta sm = start.getItemMeta();
        sm.displayName(Component.text("§a§l▶ НАЧАТЬ ТРЕНИРОВКУ"));
        sm.lore(List.of(Component.text("§7Режим: " + opt.getType().getDisplayName())));
        start.setItemMeta(sm);
        inv.setItem(16, start);

        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta bm = back.getItemMeta();
        bm.displayName(Component.text("§7← Назад к списку"));
        back.setItemMeta(bm);
        inv.setItem(22, back);

        player.openInventory(inv);
    }
}
