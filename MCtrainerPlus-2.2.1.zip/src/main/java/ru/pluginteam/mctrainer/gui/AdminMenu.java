package ru.pluginteam.mctrainer.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.pluginteam.mctrainer.MCTrainerPlugin;

import java.util.List;

public class AdminMenu {
    public static final String TITLE = "§4MCtrainer+ — Админ-панель";

    public static void open(MCTrainerPlugin plugin, Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, Component.text(TITLE));

        ItemStack flickBlock = new ItemStack(plugin.getFlickBlockMaterial());
        ItemMeta fm = flickBlock.getItemMeta();
        fm.displayName(Component.text("§eБлок мишени для Flick"));
        fm.lore(List.of(
                Component.text("§7Текущий блок: §f" + plugin.getFlickBlockMaterial().name()),
                Component.text("§aВозьмите любой блок в руку и нажмите сюда!")
        ));
        flickBlock.setItemMeta(fm);
        inv.setItem(11, flickBlock);

        ItemStack rewards = new ItemStack(Material.GOLD_INGOT);
        ItemMeta rm = rewards.getItemMeta();
        rm.displayName(Component.text("§6Награды за 10 уровней «Прогресса»"));
        rm.lore(List.of(
                Component.text("§7Изменяйте команду награды командой:"),
                Component.text("§e/mctrainer setreward <режим> <команда>"),
                Component.text("§7Пример (префикс):"),
                Component.text("§f/mctrainer setreward FLICK lp user %player% meta setprefix 100 \"&6[Flick] \"")
        ));
        rewards.setItemMeta(rm);
        inv.setItem(13, rewards);

        ItemStack reload = new ItemStack(Material.REPEATER);
        ItemMeta rlm = reload.getItemMeta();
        rlm.displayName(Component.text("§aПерезагрузить config.yml"));
        reload.setItemMeta(rlm);
        inv.setItem(15, reload);

        player.openInventory(inv);
    }
}
