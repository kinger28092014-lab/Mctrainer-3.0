package ru.pluginteam.mctrainer.command;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.model.TrainerType;

public class DuelTrainerCommand implements CommandExecutor {
    private final MCTrainerPlugin plugin;
    private final TrainerType type;

    public DuelTrainerCommand(MCTrainerPlugin plugin, TrainerType type) {
        this.plugin = plugin;
        this.type = type;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        if (args.length == 0) {
            player.sendMessage("§eИспользование: §f/" + label + " <ник> §7или §f/" + label + " accept <ник>");
            return true;
        }

        if (args.length >= 2 && args[0].equalsIgnoreCase("accept")) {
            plugin.getSessionManager().acceptDuelInvite(player, args[1], type);
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null || !target.isOnline()) {
            player.sendMessage("§cИгрок " + args[0] + " не найден в сети.");
            return true;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage("§cНельзя вызвать самого себя!");
            return true;
        }

        plugin.getSessionManager().sendDuelInvite(player, target, type);
        return true;
    }
}
