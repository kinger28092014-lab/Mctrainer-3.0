package ru.pluginteam.mctrainer.command;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.pluginteam.mctrainer.MCTrainerPlugin;
import ru.pluginteam.mctrainer.gui.AdminMenu;
import ru.pluginteam.mctrainer.model.TrainerType;

import java.util.Arrays;

public class AdminCommand implements CommandExecutor {
    private final MCTrainerPlugin plugin;

    public AdminCommand(MCTrainerPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mctrainer.admin")) {
            sender.sendMessage("§cНет прав.");
            return true;
        }

        if (args.length == 0) {
            if (sender instanceof Player player) {
                AdminMenu.open(plugin, player);
            } else {
                sender.sendMessage("Используйте /mctrainer setreward <режим> <команда> или /mctrainer reload");
            }
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            plugin.reloadConfig();
            sender.sendMessage("§aКонфиг MCtrainerPlus перезагружен!");
            return true;
        }

        if (args[0].equalsIgnoreCase("setflickblock") && sender instanceof Player player) {
            Material hand = player.getInventory().getItemInMainHand().getType();
            if (!hand.isBlock() || hand.isAir()) {
                player.sendMessage("§cВозьмите любой блок в правую руку!");
                return true;
            }
            plugin.setFlickBlockMaterial(hand);
            player.sendMessage("§aБлок для Flick изменён на §e" + hand.name() + "§a!");
            return true;
        }

        if (args[0].equalsIgnoreCase("setreward") && args.length >= 3) {
            TrainerType type;
            try {
                type = TrainerType.valueOf(args[1].toUpperCase());
            } catch (IllegalArgumentException e) {
                sender.sendMessage("§cНеизвестный режим! Доступны: TRACKING, FLICK, CLUTCH, STUNSLAM, PEARL_AIM, ANCHOR, MACE, CRYSTAL, SWORD");
                return true;
            }
            String cmd = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
            plugin.setProgressRewardCommand(type, cmd);
            sender.sendMessage("§aНаграда за 10 уровень §e" + type.name() + " §aустановлена: §f/" + cmd);
            return true;
        }

        sender.sendMessage("§eКоманды: §f/mctrainer §7| §f/mctrainer setflickblock §7| §f/mctrainer setreward <режим> <команда> §7| §f/mctrainer reload");
        return true;
    }
}
